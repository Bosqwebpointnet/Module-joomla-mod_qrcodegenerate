<?php 
/**
 * @package     mod_qrcodegenerate
 * @copyright   (C) 2025 Bosqweb.net. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
 // Charger Joomla si nécessaire
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\Registry\Registry;
 use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die("Restricted access");





// Récupérer les paramètres du module
$module = ModuleHelper::getModule('mod_qrcodegenerate');
$params = new Registry($module->params);
$apiKey = $params->get('google_api_key', '');

// Vérifier si la clé API est bien récupérée
if (empty($apiKey)) {
    die('<p style="color: red;">❌ Erreur : Clé API Google Maps introuvable.</p>');
}

// La clé API n'est pas affichée dans le HTML, elle est stockée en PHP
$app = Factory::getApplication();
$input = $app->input;

// Récupération sécurisée de "size"
$size = $input->getInt('size', 4); // Par défaut : 4 // Taille par défaut


// Utilisez la clé API passée depuis le fichier principal du module
$apiKey = isset($moduleParams['apiKey']) ? $moduleParams['apiKey'] : '';


$sampleUrl = Uri::base() . "modules/mod_qrcodegenerate/sample.php";

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>QR Code Generator</title>

    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        /* 🌟 STYLE GLOBAL - Inspiration AI */
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f6f9;
        }

        /* 🌟 STYLE UNIQUEMENT POUR LE GÉNÉRATEUR QR CODE */
        #qr-container {
            max-width: 900px;
            margin: auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-weight: 700;
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

 /* 🌟 Amélioration du style des onglets */
.qr-tabs {
    display: flex;
    justify-content: center;
    gap: 8px; /* Réduit l’espace entre les onglets */
    border-bottom: none;
    margin-bottom: 10px;
    flex-wrap: wrap; /* Permet un retour à la ligne en responsive */
    padding: 5px;
}
.qr-tab-content {
    padding-top: 10px; /* Diminue l’espace entre les onglets et le champ */
}


/* Style des onglets */
.qr-tabs .qr-tab-item {
    list-style: none;
}

/* Liens des onglets */
.qr-tabs .qr-tab-link {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 10px 16px;
    font-weight: 600;
    font-size: 14px;
    color: #333; /* Couleur plus visible */
    background: #f8f9fa;
    border-radius: 8px;
    border: 1px solid #ddd; /* Ajoute une légère bordure */
    transition: all 0.3s ease-in-out;
    text-decoration: none;
}

/* Icônes dans les onglets */
.qr-tabs .qr-tab-link svg,
.qr-tabs .qr-tab-link img {
    width: 18px;
    height: 18px;
}

/* Effet au survol */
.qr-tabs .qr-tab-link:hover {
    background: #e9ecef;
    color: #0056b3;
}

/* Onglet actif */
.qr-tabs .qr-tab-link.active {
    background: #007bff;
    color: white;
    border: 1px solid #007bff;
    box-shadow: 0px 3px 8px rgba(0, 123, 255, 0.4);
}

/* 🌟 Responsive - Empêche la déformation des onglets sur mobile */
@media (max-width: 768px) {
    .qr-tabs {
        flex-wrap: wrap;
        gap: 5px;
        justify-content: center;
    }
    
    .qr-tabs .qr-tab-link {
        padding: 8px 12px;
        font-size: 12px;
    }
}

.qr-tab-pane:not(.show) {
    display: none !important;
}
        .mb-3 {
            margin-bottom: 20px;
            margin-left: 20px;
        }

        /* 🌟 STYLE DU QR CODE */
        .qr-container-code {
            text-align: center;
            margin-top: 20px;
        }

        #loader_images {
            display: none;
            text-align: center;
            font-weight: bold;
            margin-top: 10px;
        }

        /* 🌟 STYLE UNIQUEMENT POUR L'IMAGE DU QR CODE */
        #code_img_id {
            border: 2px solid #ddd;
            padding: 12px;
            background: white;
            border-radius: 8px;
            transition: all 0.3s ease-in-out;
        }

        /* 🌟 STYLE DES CHAMPS */
        .form-control {
            border-radius: 8px;
            padding: 12px;
            font-size: 16px;
        }

        .form-label {
            font-weight: 600;
            color: #555;
        }

        /* Boutons pour rendre l’interface plus intuitive */
        .generate-btn {
            display: block;
            width: 100%;
            background: #007bff;
            color: white;
            border: none;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            margin-top: 10px;
            transition: all 0.3s;
        }

        .generate-btn:hover {
            background: #0056b3;
        }

        /* Ajuste la taille des inputs */
        .form-control-color {
            width: 50px !important;
            height: 35px !important;
            padding: 0 !important;
            border: none;
            cursor: pointer;
        }

        /* Ajuste l'input de taille */
        #qrSize {
            width: 80px;
            /* Taille optimisée */
            height: 35px;
            text-align: center;
        }

        /* Améliore l'espacement */
        .d-flex.align-items-center {
            gap: 5px;
        }

        /* Style du texte explicatif sous la taille */
        .text-muted {
            font-size: 12px;
            color: #666;
        }

        .qr-size-selector {
            margin-top: 10px;
        }

        .qr-size-option {
            display: inline-block;
            padding: 6px 12px;
            background: #f8f9fa;
            color: #007bff;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s ease-in-out;
        }

        .qr-size-option:hover {
            background: #007bff;
            color: white;
        }

        .qr-size-option.active {
            background: #007bff;
            color: white;
            box-shadow: 0px 3px 8px rgba(0, 123, 255, 0.4);
        }
        
        .qr-ec-selector {
    margin-top: 10px;
}

.qr-ec-option {
    padding: 6px 12px;
    border-radius: 5px;
    background: #f8f9fa;
    border: 1px solid #ddd;
    font-weight: bold;
    color: #007bff;
    transition: all 0.3s ease-in-out;
    cursor: pointer;
}

.qr-ec-option:hover {
    background: #007bff;
    color: white;
}

.qr-ec-option:focus {
    border-color: #007bff;
    box-shadow: 0px 3px 8px rgba(0, 123, 255, 0.4);
}

    </style>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
        
<script>
//ajust googlemap
    let map;
    let marker;

    function initMap() {
        console.log("Google Maps API chargée");

        // Récupérer la clé API via PHP côté serveur
        let apiKey = "<?= htmlspecialchars($params->get('google_api_key', '')); ?>";

        if (!apiKey) {
            console.error("❌ Erreur : Clé API Google Maps introuvable.");
            return;
        }

        // Charger dynamiquement l'API Google Maps
        let script = document.createElement("script");
        script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=initializeMap`;
        script.defer = true;
        document.body.appendChild(script);
    }

    function initializeMap() {
        console.log("Carte initialisée");

        map = new google.maps.Map(document.getElementById("googleMapContainer"), {
            center: { lat: 48.8566, lng: 2.3522 }, // Coordonnées par défaut (Paris)
            zoom: 14
        });

        marker = new google.maps.Marker({
            position: { lat: 48.8566, lng: 2.3522 },
            map: map,
            title: "Localisation"
        });

        $("#googleMapContainer").show(); // Afficher la carte
    }

    $(document).ready(function() {
        $("#map").on("keyup", function() {
            let address = $(this).val().trim();
            let apiKey = "<?= htmlspecialchars($params->get('google_api_key', '')); ?>";

            if (address.length > 3) {
                let geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${apiKey}`;

                // Récupérer les coordonnées de l'adresse avec l'API Geocoding
                $.getJSON(geocodeUrl, function(response) {
                    if (response.status === "OK") {
                        let location = response.results[0].geometry.location;

                        // Déplacer la carte et le marqueur
                        map.setCenter(location);
                        marker.setPosition(location);
                        $("#googleMapContainer").show();
                    } else {
                        console.error("❌ Erreur Google Maps : " + response.status);
                    }
                }).fail(function() {
                    console.error("❌ Erreur lors de la requête AJAX.");
                });
            } else {
                $("#googleMapContainer").hide();
            }
        });

        // Initialiser Google Maps après le chargement de la page
        initMap();
    });
</script>

</head>

<body>

    <div id="qr-container" class="container">
        <h2>QR Code Generator</h2>

<!-- Onglets -->
<ul class="qr-tabs" id="qrTabs">
    <li class="qr-tab-item"><a class="qr-tab-link active" data-bs-toggle="tab" href="#urlTab" data-type="url">🔗 URL</a></li>
    <li class="qr-tab-item"><a class="qr-tab-link" data-bs-toggle="tab" href="#phoneTab" data-type="phone">📞 Téléphone</a></li>
    <li class="qr-tab-item"><a class="qr-tab-link" data-bs-toggle="tab" href="#smsTab" data-type="sms">✉️ SMS</a></li>
    <li class="qr-tab-item"><a class="qr-tab-link" data-bs-toggle="tab" href="#textTab" data-type="text">📝 Texte</a></li>
    <li class="qr-tab-item"><a class="qr-tab-link" data-bs-toggle="tab" href="#mailTab" data-type="mail">📧 Mail</a></li>
    <li class="qr-tab-item"><a class="qr-tab-link" data-bs-toggle="tab" href="#youtubeTab" data-type="youtube">🎥 YouTube</a></li>
    <li class="qr-tab-item"><a class="qr-tab-link" data-bs-toggle="tab" href="#mapTab" data-type="map">🗺️ Google Maps</a></li>
</ul>

        <!-- Contenu des onglets -->
        <div class="qr-tab-content">
            <div class="qr-tab-pane fade show active" id="urlTab">
                <div class="mb-3">
<label class="form-label"><?php echo Text::_('MOD_QRCODEGENERATE_URL'); ?>:</label>
<input type="text" class="form-control qr-input" id="url" placeholder="<?php echo Text::_('MOD_QRCODEGENERATE_URL_DESC'); ?>">
                </div>
            </div>
            <div class="qr-tab-pane fade" id="phoneTab">
                <div class="mb-3">
<label class="form-label"><?php echo Text::_('MOD_QRCODEGENERATE_PHONE'); ?>:</label>
<input type="text" class="form-control qr-input" id="phone" placeholder="<?php echo Text::_('MOD_QRCODEGENERATE_PHONE_DESC'); ?>">
                </div>
            </div>
            <div class="qr-tab-pane fade" id="smsTab">
                <div class="mb-3">
<label class="form-label"><?php echo Text::_('MOD_QRCODEGENERATE_SMS'); ?> :</label>
<input type="text" class="form-control qr-input" id="sms_no" placeholder="<?php echo Text::_('MOD_QRCODEGENERATE_SMS_DESC'); ?>">
<label class="form-label mt-2"><?php echo Text::_('MOD_QRCODEGENERATE_SMS'); ?> :</label>
<textarea class="form-control qr-input" id="sms_msg" placeholder="<?php echo Text::_('MOD_QRCODEGENERATE_SMS_DESC'); ?>"></textarea>
                </div>
            </div>
            <div class="qr-tab-pane fade" id="textTab">
                <div class="mb-3">
                    <label class="form-label">Texte :</label>
                    <textarea class="form-control qr-input" id="text"></textarea>
                </div>
            </div>
            <div class="qr-tab-pane fade" id="mailTab">
                <div class="mb-3">
                    <label class="form-label">Email :</label>
                    <input type="email" class="form-control qr-input" id="mail">
                </div>
            </div>
            <div class="qr-tab-pane fade" id="youtubeTab">
                <div class="mb-3">
<label class="form-label"><?php echo Text::_('MOD_QRCODEGENERATE_YOUTUBE'); ?> :</label>
<input type="text" class="form-control qr-input" id="youtube" placeholder="<?php echo Text::_('MOD_QRCODEGENERATE_YOUTUBE_DESC'); ?>">
                </div>
            </div>
        </div>

        <!-- Google Maps -->
        <div class="qr-tab-pane fade" id="mapTab">
            <div class="mb-3">
                <label class="form-label"><?php echo Text::_('MOD_QRCODEGENERATE_MAP'); ?> :</label>
                <input type="text" class="form-control qr-input" id="map"
                    placeholder="Ex: Tour Eiffel ou 48.8588443,2.2943506">
                   

            </div>
      <div id="googleMapContainer" style="width: 100%; height: 400px; display: none;">
    <!-- La carte sera affichée ici -->
</div>

        </div>
        <!-- Color QRCode -->
        <div class="d-flex flex-wrap align-items-center gap-3 mb-3">
            <!-- Couleur de fond -->
            <div class="d-flex align-items-center">
                <label class="form-label me-2">🎨 Fond :</label>
                <input type="color" class="form-control form-control-color" id="backColor" value="#FFFFFF">
            </div>

            <!-- Couleur des barres -->
            <div class="d-flex align-items-center">
                <label class="form-label me-2">🖋️ Barres :</label>
                <input type="color" class="form-control form-control-color" id="barColor" value="#000000">
            </div>

            <!-- Taille du QR Code -->
            <div class="qr-size-selector d-flex flex-wrap align-items-center gap-2">
                <label class="form-label me-2">📏 Taille :</label>
                <?php for ($i = 1; $i <= 10; $i++) : ?>
                <a href="<?php echo $sampleUrl . '&size=' . $i; ?>"
                    class="qr-size-option <?php echo ($i == $size) ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
                <?php endfor; ?>
            </div>
            <small class="text-muted mt-1">
                Valeurs min/max : <strong>1</strong> (min) à <strong>10</strong> (max).<br>
                Par défaut, la taille est fixée à <strong>4</strong>.
            </small>
            <!-- Sélecteur du niveau de correction d'erreur -->
<div class="qr-ec-selector d-flex flex-wrap align-items-center gap-2">
    <label class="form-label me-2">🔧 Correction d'erreur :</label>
    <select id="EC_LEVEL" class="form-control qr-ec-option">
        <option value="L" selected>Low (7%)</option>
        <option value="M">Medium (15%)</option>
        <option value="Q">Quartile (25%)</option>
        <option value="H">High (30%)</option>
    </select>
</div>

        </div>

        <!-- Generator QRCode -->
        <div class="qr-container-code">
            <p id="loader_images">Génération en cours...</p>
            <img id="code_img_id" src="https://www.bosqweb.net/qrcode/sample.php?type=text&text=Bosqweb.net">
        </div>
    </div>


 

    <script>

(function($) {
    $(function() {
        let currentType = "text";
        let params = { text: "Bosqweb.net" };

        // Fonction de validation d'URL
        function isValidURL(url) {
            var pattern = new RegExp('^(https?:\\/\\/)?' + // protocole
                '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // nom de domaine
                '((\\d{1,3}\\.){3}\\d{1,3}))' + // OU adresse ip (v4)
                '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port et chemin
                '(\\?[;&a-z\\d%_.~+=-]*)?' + // paramètres de requête
                '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
            return !!pattern.test(url);
        }

        $(".qr-tab-link").on("click", function(e) {
            e.preventDefault();
            $(".qr-tab-link").removeClass("active");
            $(this).addClass("active");

            currentType = $(this).data("type");
            params = {};

            $(".qr-input").val("");
            $(".qr-tab-pane").removeClass("show active");
            $($(this).attr("href")).addClass("show active");

            generateQRCode();
        });


        //googlemap
console.log("Adresse envoyée :", address);
console.log("Clé API envoyée :", apiKey);
   $(document).ready(function() {
        $("#map").on("keyup", function() {
            let address = $(this).val().trim();
            let googleMapContainer = $("#googleMapContainer");
            let googleMapFrame = $("#googleMapFrame");
            let debugInfo = $("#debugInfo"); // Élément pour afficher les infos

            // Récupérer la clé API via PHP (elle n'est jamais visible dans le HTML)
            let apiKey = "<?php echo htmlspecialchars($moduleParams['apiKey'] ?? ''); ?>";

            console.log("Adresse envoyée :", address);
            console.log("Clé API envoyée :", apiKey);

            if (address.length > 3) {
                // Afficher les informations envoyées à Google Maps API
                debugInfo.html("<p>🔹 Adresse envoyée : <strong>" + address + "</strong></p>" +
                               "<p>🔹 Clé API : <strong>🔒 Sécurisée</strong></p>");

                // Met à jour directement l'iframe avec Google Maps Embed API
                let googleMapUrl = `https://www.google.com/maps/embed/v1/place?key=${apiKey}&q=${encodeURIComponent(address)}`;

                googleMapFrame.attr("src", googleMapUrl);
                googleMapContainer.show();
            } else {
                googleMapContainer.hide();
                debugInfo.html("<p>⚠️ Entrez au moins 4 caractères pour rechercher une adresse.</p>");
            }
        });
    });



        //fonction couleur qrcode

        // Écoute les changements sur les couleurs et conserve la taille sélectionnée
        $("#backColor, #barColor").on("input", function() {
            let backColor = $("#backColor").val().replace("#", ""); // Convertir HEX en format attendu
            let barColor = $("#barColor").val().replace("#", ""); // Convertir HEX en format attendu

            // Récupérer la taille actuelle depuis sessionStorage ou l'input
            let qrSize = sessionStorage.getItem("qrSize") || $("#qrSize").val();

            // S'assurer que qrSize reste entre 1 et 10
            qrSize = Math.min(Math.max(parseInt(qrSize, 10) || 4, 1), 10);

            // Ajouter les couleurs et la taille aux paramètres existants
            params["bc"] = backColor;
            params["barc"] = barColor;
            params["size"] = qrSize;

            // Stocker la taille dans sessionStorage pour éviter la réinitialisation
            sessionStorage.setItem("qrSize", qrSize);

            generateQRCode();
        });



        //Fonction qr input

        $(".qr-input").on("keyup", function() {
            let fieldType = $(this).attr("id");
            let value = $(this).val().trim();
            params = {};

            if (currentType === "sms") {
                if (fieldType === "sms_no") params["txt"] = value;
                if (fieldType === "sms_msg") params["message"] = value;
            } else if (currentType === "phone") {
                params["no"] = value;
            } else if (currentType === "text") {
                params["text"] = value;
            } else if (currentType === "mail") {
                params["url"] = "mailto:" + value;
            } else if (currentType === "youtube") {
                params["url"] = "http://youtube.com/user/" + value;
            } else if (currentType === "map") {
                getGoogleMap(value);
            } else if (currentType === "url") {
                // Validation d'URL
                if (isValidURL(value)) {
                    params["url"] = value;
                } else {
                    // URL invalide, ne pas générer de QR code
                    return;
                }
            } else {
                params["url"] = value;
            }

            generateQRCode();
        });
        
//-----fonction generate qrcode------
        
        
        function generateQRCode() {
            if (!Object.values(params).some(value => value !== "")) {
                params = { text: "https://www.bosqweb.net" };
                currentType = "text";
            }

            let qrSize = sessionStorage.getItem("qrSize") || "4"; // ✅ Utilise la taille choisie ou 4 par défaut
            // Récupérer la taille choisie
                let errorCorrectionLevel = $("#EC_LEVEL").val(); // ✅ Récupère le niveau de correction sélectionné
            let fullUrl = "https://www.bosqweb.net/qrcode/sample.php?type=" + encodeURIComponent(currentType);


            for (const key in params) {
                fullUrl += `&${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`;
            }

            fullUrl += `&size=${qrSize}`; // Ajouter la taille à l'URL du QR Code
            fullUrl += `&EC_LEVEL=${errorCorrectionLevel}`; // ✅ Ajoute le niveau de correction
            $("#loader_images").show();
            $("#code_img_id").attr("src", fullUrl).on("load", function() {
                $("#loader_images").hide();
            });
        }

        generateQRCode();
    });
})(jQuery);
//-----end----



function isWebGLAvailable() {
    try {
        const canvas = document.createElement('canvas');
        return !!(window.WebGLRenderingContext && (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
    } catch (e) {
        return false;
    }
}

//-----selection taille-----

document.addEventListener("DOMContentLoaded", function() {
    const qrSizeOptions = document.querySelectorAll(".qr-size-option");
    const qrCodeImage = document.getElementById("code_img_id");

    // Récupérer la taille actuelle depuis l'URL ou stockée en session
    let currentSize = sessionStorage.getItem("qrSize") || "4";

    function updateQRCode() {
        let baseUrl = qrCodeImage.src.split("&size=")[0]; // Supprimer l'ancienne taille
        qrCodeImage.src = baseUrl + "&size=" + currentSize;

        // Afficher un message temporaire pour confirmer le changement
        let loader = document.getElementById("loader_images");
        loader.style.display = "block";
        qrCodeImage.onload = () => loader.style.display = "none";
    }

    // Appliquer la taille sélectionnée à l'initialisation
    qrSizeOptions.forEach(option => {
        if (option.getAttribute("href").includes("size=" + currentSize)) {
            option.classList.add("active");
        }
        option.addEventListener("click", function(event) {
            event.preventDefault(); // Empêcher le rechargement de la page

            // Mettre à jour la taille actuelle
            currentSize = this.getAttribute("href").split("size=")[1];
            sessionStorage.setItem("qrSize", currentSize); // Sauvegarder dans le stockage de session

            // Mettre à jour visuellement le bouton actif
            qrSizeOptions.forEach(el => el.classList.remove("active"));
            this.classList.add("active");

            // Mettre à jour le QR Code
            updateQRCode();
        });
    });

    // S'assurer que la taille est conservée sur les autres interactions
    document.querySelectorAll(".qr-input, #backColor, #barColor").forEach(input => {
        input.addEventListener("input", function() {
            updateQRCode();
        });
    });
});
//-----Erreur bootstrap----
$(document).ready(function() {
    // Activer les tooltips Bootstrap s'ils sont manquants
    if ($.fn.tooltip === undefined) {
        console.warn("Tooltip Bootstrap non chargé, activation forcée...");
        $.getScript("https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js");
    }

    // Réactiver les tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();
});

//--------------------------
jQuery.noConflict();
(function($) {
    $(document).ready(function() {
        // Ton code ici
    });
})(jQuery);
//-------------------------
if (!isWebGLAvailable()) {
    alert("Les cartes vectorielles ne sont pas prises en charge par votre navigateur. Vous verrez une carte raster.");
}
</script>

  
    
    
    
</body>



</html>

