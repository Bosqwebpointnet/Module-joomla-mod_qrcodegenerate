function createRequestObject_com() {
var ro;
var browser = navigator.appName;
if(browser == "Microsoft Internet Explorer"){
ro = new ActiveXObject("Microsoft.XMLHTTP");
}else{
ro = new XMLHttpRequest();
}
return ro;
}

var http = createRequestObject_com();
var pass_id1 = "";

function randOrd(){
return (Math.round(Math.random())-0.5); }

function sndReq_com(url,para,pass_id) {
pass_id1 = pass_id;

anyArray = new Array('3','a','5','F','x','47');
var rand_var = anyArray.sort( randOrd );

var url1=url+para+"&"+rand_var;

http.open('post', url1);
http.onreadystatechange = handleResponse_comm;
//alert(para);
http.send(null);
//setTimeout("sndReq()", 60000); // Recursive JavaScript function calls sndReq() every 2 seconds
}

function handleResponse_comm() {
//document.getElementById(pass_id1).innerHTML = 'Loading...'; 
if(http.readyState == 4){
	var response = http.responseText;
	if(pass_id1!=""){
		document.getElementById(pass_id1).innerHTML = http.responseText;
	}else{
		document.getElementById('latlang').value = http.responseText;
	}
}
}

