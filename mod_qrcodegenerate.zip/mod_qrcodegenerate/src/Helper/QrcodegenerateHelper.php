<?php
/**
 * @package     mod_qrcodegenerate
 * @copyright   (C) 2025 Bosqweb.net. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
namespace Bosqweb\Module\Qrcodegenerate\Site\Helper;

use Joomla\CMS\Cache\CacheControllerFactoryInterface;
use Joomla\CMS\Cache\Controller\OutputController;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
defined('_JEXEC') or die("Restricted access");
/**
 * Helper class for the QR code generation module
 */
class QrcodegenerateHelper
{
    /**
     * Récupère la clé API depuis l'entrée utilisateur
     *
     * @return string La clé API filtrée
     */
     
     public static function getMapDataAjax()
    {
        // Effectuez votre logique ici (accéder à la base de données, appeler des API, etc.)
        // ...

        // Obtenir la clé API depuis les paramètres du module
        $module = ModuleHelper::getModule('mod_qrcodegenerate'); // Charger le module pour obtenir les paramètres
        $params = new \Joomla\Registry\Registry($module->params);
        $apiKey = $params->get('google_api_key');

        // Données d'exemple - remplacez par vos données réelles
        $data = array(
            'latitude' => 48.8566,
            'longitude' => 2.3522,
            'apiKey' => $apiKey
        );

        // Retourner les données au format JSON
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    
 public static function getApiKey(): string
    {
        $app = Factory::getApplication();
        $input = $app->input;

        // Vérifier si la clé API est fournie en paramètre d'URL
        $apiKey = $input->getString('api_key', '');

        // Si aucune clé API n'est fournie via l'URL, récupérer celle du module
        if (empty($apiKey)) {
            $params = self::getModuleParams();
            $apiKey = $params['google_api_key'] ?? '';
        }

        return trim($apiKey);
    }
    /**
     * Génère l'URL pour accéder au fichier getmap.php avec la clé API
     *
     * @param string $apiKey La clé API
     * @return string L'URL générée
     */
    public static function generateGetMapUrl(string $apiKey): string
    {
        return Uri::base() . "modules/mod_qrcodegenerate/ajax/getmap.php?api_key=" . urlencode($apiKey);
    }

    /**
     * Charge les paramètres du module
     *
     * @return array Les paramètres du module sous forme de tableau associatif
     */
    public static function getModuleParams(): array
    {
        $module = Factory::getApplication()->getModule('mod_qrcodegenerate');
        return json_decode($module->params, true) ?? [];
    }
    
    
     /**
     * Fonction pour récupérer les coordonnées d'une adresse
     */
    public static function getLangLat($address, $apiKey)
    {
        $google_address = urlencode($address);
        $url = "https://maps.googleapis.com/maps/api/geocode/json?address=$google_address&key=" . $apiKey;

        // Utilisation de cURL pour obtenir les données
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);
        curl_close($ch);

        // Décoder la réponse JSON
        $data = json_decode($response, true);

        if ($data["status"] === "OK") {
            $lat = $data["results"][0]["geometry"]["location"]["lat"];
            $lng = $data["results"][0]["geometry"]["location"]["lng"];
            return "$lat,$lng";
        } else {
            return false;
        }
    }

}

?>

