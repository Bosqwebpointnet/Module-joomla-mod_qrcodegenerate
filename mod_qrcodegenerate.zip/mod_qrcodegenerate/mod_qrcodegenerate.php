<?php
/**
 * @package     mod_qrcodegenerate
 * @copyright   (C) 2025 Bosqweb.net. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// Protection contre les appels directs
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;
use Bosqweb\Module\Qrcodegenerate\Helper\QrcodegenerateHelper;

// Récupérer les paramètres du module via ModuleHelper
$module = ModuleHelper::getModule('mod_qrcodegenerate');
$params = (array) json_decode($module->params);
$apiKey = isset($params['google_api_key']) ? $params['google_api_key'] : '';
$size = isset($params['size']) ? $params['size'] : 4; // Taille par défaut

// Rendre les paramètres disponibles pour le layout
$moduleParams = [
    'apiKey' => $apiKey,
    'size' => $size
];

$lang = Factory::getApplication()->getLanguage();
$lang->load('mod_qrcodegenerate', JPATH_SITE, null, true);

// Charger le fichier de mise en page du module
require ModuleHelper::getLayoutPath('mod_qrcodegenerate', 'default');


?>
